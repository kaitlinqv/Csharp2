﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MidtermLogin
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private string LOGIN = "admin";
        private string PASSWORD = "admin";
        private int ATTEMPT = 0;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            ATTEMPT++;  //incriment
            if(loginBox.Text == LOGIN && pwordBox.Text == PASSWORD)
            {
                MessageBox.Show("You entered the correct password!");
            }else
            {
                MessageBox.Show("You entered the WRONG password!");
                if (ATTEMPT == 3)
                {
                    MessageBox.Show("You entered the wrong password too many times!");
                    loginBox.IsEnabled = false;
                    pwordBox.IsEnabled = false;
                    loginButt.IsEnabled = false;
                }


            }


        }

        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
