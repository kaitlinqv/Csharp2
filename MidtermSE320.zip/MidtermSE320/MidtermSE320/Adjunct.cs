﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MidtermSE320
{
    class Adjunct : Professor
    {
        //private members
        private double hourlyRate;

        //constructor
        public Adjunct():this(0,"",0)  //base constructor
        {

        }
        public Adjunct(double hourlyRate, string name, int years)
            :base(name,years,false,0)  //full constructor with isTenured false and salary=0
        {
            this.hourlyRate = hourlyRate;
        }  //end constructors
        //get & set
        public double HourlyRate
        {
            get { return hourlyRate; }
            set { hourlyRate = value; }
        }
        //other methods
        public override string ToString()  //override display for adjunct
        {
            return base.ToString() + "\nHourly Rate: " + Convert.ToString(hourlyRate);
        }
    }
}
