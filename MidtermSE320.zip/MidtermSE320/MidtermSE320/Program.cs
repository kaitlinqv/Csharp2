﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MidtermSE320
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exception = false; //exception catching
            Professor prof1 = new Professor();
            Professor prof2 = new Professor();
            Professor prof3 = new Professor();
            for(int i= 0; i<3; i++)  //3 count loop
            {

                do //loop for names
                {
                    try//try catch
                    {
                        Console.Write("\nName: ");
                        switch (i)  //switch so i can keep using this for loop
                        {
                            case 0:
                                prof1.Name = Console.ReadLine(); 
                                break;
                            case 1:
                                prof2.Name = Console.ReadLine(); 
                                break;
                            default:
                                prof3.Name = Console.ReadLine(); 
                                break;
                        }  //end switch
                        exception = false;

                    }catch (Exception e) //catch exceptions!
                    {
                        Console.WriteLine(e.Message);
                        exception = true;
                    }

                } while (exception);  //while exception is true

                do //loop for years
                {
                    try//try catch
                    {
                        Console.Write("\nYears(0-50): ");
                        switch (i)  //switch so i can keep using this for loop
                        {
                            case 0:
                                prof1.Years = Convert.ToInt32(Console.ReadLine());
                                break;
                            case 1:
                                prof2.Years = Convert.ToInt32(Console.ReadLine());
                                break;
                            default:
                                prof3.Years = Convert.ToInt32(Console.ReadLine());
                                break;
                        }  //end switch
                        exception = false;

                    }
                    catch (Exception e) //catch exceptions!
                    {
                        Console.WriteLine(e.Message);
                        exception = true;
                    }

                } while (exception);  //while exception is true

                do //loop for tenure
                {
                    try//try catch
                    {
                        Console.Write("\nTenure 0-no, 1-yes: ");

                        switch (i)  //switch so i can keep using this for loop
                        {
                            case 0:
                                prof1.IsTenured = Convert.ToInt32(Console.ReadLine()) == 1 ? true : false;
                                break;
                            case 1:
                                prof2.IsTenured = Convert.ToInt32(Console.ReadLine()) == 1 ? true : false;
                                break;
                            default:
                                prof3.IsTenured = Convert.ToInt32(Console.ReadLine()) == 1 ? true : false;
                                break;
                        }  //end switch
                        exception = false;

                    }
                    catch (Exception e) //catch exceptions!
                    {
                        Console.WriteLine(e.Message);
                        exception = true;
                    }

                } while (exception);  //while exception is true

                do //loop for salary
                {
                    try//try catch
                    {
                        Console.Write("\nSalary: ");
                        switch (i)  //switch so i can keep using this for loop
                        {
                            case 0:
                                prof1.Salary = Convert.ToDouble(Console.ReadLine());
                                break;
                            case 1:
                                prof2.Salary = Convert.ToDouble(Console.ReadLine());
                                break;
                            default:
                                prof3.Salary = Convert.ToDouble(Console.ReadLine());
                                break;
                        }  //end switch
                        exception = false;

                    }
                    catch (Exception e) //catch exceptions!
                    {
                        Console.WriteLine(e.Message);
                        exception = true;
                    }

                } while (exception);  //while exception is true


            }  //end for loop

            Adjunct addy = new Adjunct(23, prof2.Name, prof2.Years);

            Console.WriteLine(prof1.ToString());  //display professors
            Console.WriteLine(prof2.ToString());
            Console.WriteLine(prof3.ToString());
            Console.WriteLine(addy.ToString());

            //add array list to hold professor peoples
            ArrayList newlist = new ArrayList();
            newlist.Add(prof1);
            newlist.Add(prof2);
            newlist.Add(prof3);
            newlist.Add(addy);

            foreach (var element in newlist)
            {
                Console.Write("{0}", element);
            }
            Console.Read();  //catch
            
        }
    }
}
