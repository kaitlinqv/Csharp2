﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MidtermSE320
{
    class Professor
    {
        //private members
        private string name;
        private int years;
        private bool isTenured;
        private double salary;

        //constructors
        public Professor() :this("",0,false,0)  //base
        {

        }  //end constructor

        public Professor(string name, int years, bool isTenured, double salary)  //full
        {
            this.name = name;
            this.years = years;
            this.isTenured = isTenured;
            this.salary = salary;
        }  //end constructor

        //get and set stuff
        public string Name  
        {
            get { return name; }
            set { name = value; }
        }  //end name get & set

        public int Years  //years get & set
        {
            get { return years; }
            set
            {
                if (value < 0 || value > 50)  //check for value, 0-50
                    throw new ArgumentOutOfRangeException("value must be 0-50");
                else
                    years = value;
            } //end set
        }  //end years get & set

        public bool IsTenured
        {
            get { return isTenured; }
            set { isTenured = value; }           
        }  //end isTenured get & set

        public double Salary
        {
            get { return salary; }
            set { salary = value; }
        }  //end salary get & set

        //other methods
        public override string ToString()  //overridden ToString method to output class
        {
            return string.Format("\nName: {0}\nYears: {1}\n Tenure: {2}\n Salary: {3}\n", name, years, isTenured ? "YES" : "NO" , salary);
        }  //end toString

        public override Professor operator+(Professor p1, Professor p2)  //maybe?
        {
            return p1 + p2;
        }
    }
}
